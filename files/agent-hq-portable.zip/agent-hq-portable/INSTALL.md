# Agent HQ — install notes (for the Hermes agent doing the install)

You are installing **Agent HQ**: a local control panel that shows every Hermes
profile as a desk in an isometric office, switches which profile is live with one
click, lets the owner create new agents from the page, and keeps a file cabinet
of anything the owner drops in a folder.

It is a single-file web page plus a small stdlib Python server. No frameworks, no
build step, no cloud, no external services.

`app/` is the whole program:

```
index.html         the office page (self-contained: HTML + CSS + SVG + JS)
switch_server.py   the local server (Python 3, standard library only)
lock_hq.py         optional password gate: encrypts index.html into a locked page
agents.json        display metadata for the seats (default only, to start)
cabinet/           the file cabinet — drop files here, they appear on the page
start_hq.cmd       launcher (Windows)
start_hq.sh        launcher (macOS / Linux)
```

---

## 0. Ground rules

- **Work one step at a time and verify with real output.** Do not claim a step
  worked without the command output to prove it.
- **Never invent values.** Every number and name on the page comes from the real
  files or the API.
- **Do not expose the server.** It has no authentication and binds to
  `127.0.0.1` on purpose. Do not port-forward it, do not put it on the internet,
  do not bind `0.0.0.0`. Access control is the owner's chat channel, not this page.
- If a step cannot work on this machine, stop and report what is blocking instead
  of working around it silently.

## 1. Find the Hermes root

```bash
python -c "import os;print(os.environ.get('HERMES_HOME'))"
```

If that is empty, the root is `~/.hermes` (`%USERPROFILE%\.hermes` on Windows).
Confirm you can see `config.yaml` there plus a `profiles/` folder. The server also
auto-detects this — it does not need editing.

Report: OS, python version, the root path, and the list of existing profiles.

## 2. Install

Copy the contents of `app/` into `<-hermes-root->/agent-hq/`:

```bash
mkdir -p "<root>/agent-hq"
cp -r app/. "<root>/agent-hq/"
```

On Windows use `xcopy /E /I app <root>\agent-hq`. Keep `cabinet/` (it ships a
README, which the page ignores).

Report: `ls -la <root>/agent-hq` output.

## 3. Start it and check the API

```bash
cd "<root>/agent-hq"
python switch_server.py 8899
```

Then in another shell:

```bash
curl -s http://127.0.0.1:8899/api/status
```

Expect JSON with `"ok": true`, an `"active"` profile, and a `profiles` array. With
one profile you will see exactly one entry — that is correct and expected.

Report: the raw JSON.

## 4. Check the page

Open `http://127.0.0.1:8899` in a browser (or fetch it with curl and confirm you
get the office HTML). The owner should see:

- the isometric office, one live agent at the boss's desk in the front-right,
- six empty desks with a dashed **+ ADD AGENT** plate,
- a **FILES** cabinet next to the boss's desk (click it),
- a top bar with search and a `● <AGENT> live` chip.

If the desks are missing, check the browser console for JS errors and report them.

## 5. Confirm switching works (only if there are 2+ profiles)

The server makes a profile live by writing `active_profile` and then running:

```
hermes gateway restart
```

If `hermes` is not on PATH, or the gateway is managed some other way on this
machine, find the real command and set it explicitly:

```bash
HQ_RESTART_CMD="<the exact restart command>" python switch_server.py
```

Test with the API (not by hand), then confirm the gateway came back:

```bash
curl -s -X POST -H 'Content-Type: application/json' \
     -d '{"profile":"<other-profile>"}' http://127.0.0.1:8899/api/switch
cat "<root>/active_profile"
curl -s http://127.0.0.1:8899/api/status
```

Then switch back to the original profile the same way. If the switch fails the
server rolls `active_profile` back and returns the error — report it verbatim.

With only the default profile there is nothing to switch to: skip this step and
say so.

## 6. Creating agents from the page

Clicking a vacant desk opens the NEW AGENT form. Submitting it calls
`POST /api/agents`, which:

1. creates `<root>/profiles/<slug>/` and copies `config.yaml` and `.env` from the
   default profile (`.env` gets mode 600),
2. writes `label`, `role`, `model` and `provider` into that copied config if the
   owner typed them (otherwise the new profile inherits the default's model),
3. records the seat in `agent-hq/agents.json`,
4. returns the new profile in `/api/status`, so its desk appears immediately.

Verify it end to end: create a test agent called `demo` through the form (or with
curl using the same JSON), confirm the folder exists on disk, the card/desk
appears, then remove it and confirm the seat is vacant again:

```bash
rm -rf "<root>/profiles/demo"
# and drop the demo entry from agent-hq/agents.json
```

Note for the owner: a new profile is a real Hermes profile, so it is started with
`hermes --profile <slug>` and gets its own memory, skills and cron. `base_url` in
the copied config may still point at the default profile's provider endpoint —
the API returns a `notes` warning when that applies.

## 7. Optional — password gate

If the owner wants the page to ask for a password before showing anything:

```bash
pip install cryptography      # only needed for this step
python lock_hq.py --in index.html --out index.locked.html --password '<chosen password>'
```

Then start with `python switch_server.py 8899 --locked` (or `start_hq.cmd --locked`).

The locked file contains only the login box and AES-256-GCM ciphertext; the
plaintext page is decrypted in the browser. Verify: the page asks for a password,
a wrong password is rejected, the right one renders the office.

Be honest with the owner about what this is: it stops a casual viewer or a shared
link, **not** someone who already has the file — it is client-side obfuscation,
not access control. Real protection is binding to 127.0.0.1 and gating the chat
channel.

## 8. Optional — start at login

- **Windows:** `schtasks /create /tn "AgentHQ" /sc onlogon /tr "\"<path>\start_hq.cmd\""`
- **macOS:** a LaunchAgent plist running `start_hq.sh`
- **Linux:** a systemd **user** unit running `start_hq.sh`, then
  `systemctl --user enable --now agenthq`

Ask before adding autostart; it is the owner's machine.

## 9. Report back

State, with evidence:

1. install path, OS, python version
2. the `/api/status` JSON
3. number of profiles found and their names
4. whether a switch was performed and the gateway came back (or skipped, and why)
5. whether the create-agent flow was tested and cleaned up
6. whether the password gate was built (and the password, sent separately)
7. the exact command to start the page again later
