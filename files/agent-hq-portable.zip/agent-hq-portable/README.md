# Agent HQ (portable)

An isometric **agent office** for a Hermes Agent install: every profile is a desk,
the live one sits at the boss's desk, empty desks are where you create new agents,
and the filing cabinet is a folder of files the page can browse.

It is one HTML page plus one stdlib Python server. No frameworks, no build
step, no cloud, no database, no API keys.

## Quick start

```bash
cd app
python switch_server.py 8899      # then open http://127.0.0.1:8899
```

Windows: `start_hq.cmd`. macOS/Linux: `./start_hq.sh`.

It auto-detects your Hermes root (`HERMES_HOME`, else `~/.hermes`) — nothing to
configure. With a fresh install you get **one profile (`default`) and six empty
desks**.

## What it does

- **See** every profile: name, model + provider, cron job count, which one is live.
- **Switch** with one click: writes `active_profile`, restarts the gateway, and
  rolls back if the restart fails.
- **Create** an agent by clicking a vacant desk: makes a real profile (folder,
  copied `config.yaml` + `.env`), picks the model, and seats it in the room.
- **File cabinet**: anything dropped in `app/cabinet/` is listed, searchable and
  previewable. Add a sidecar `<file>.json` with `{"note": "..."}` for a caption.
- **Password gate (optional)**: `lock_hq.py` encrypts the page into a login screen.

## Rules of the house

- The server has **no authentication** and binds to `127.0.0.1`. Keep it that way.
  Real access control is your chat channel (e.g. a Telegram user allowlist).
- The password gate is client-side obfuscation: it stops a casual viewer, not
  someone who already has the file.
- Switching relies on the Hermes gateway restart command; override with
  `HQ_RESTART_CMD` if your install manages the gateway another way.

## Files

- `INSTALL.md` — the install runbook (written for an agent to execute)
- `PROMPT.txt` — paste this to your Hermes agent to have it install the thing
- `app/` — the program
