# File cabinet

Everything you drop in this folder shows up in the **File cabinet** drawer of the
Agent HQ page (the filing cabinet in the office scene, next to the boss's desk).

- Files are listed newest first, searchable by name and note.
- Images, video and audio preview inline; documents download.
- `README.md` and dotfiles are ignored.

## Adding a note to a file

Drop a sidecar JSON next to it with the same name plus `.json`:

```
report.pdf
report.pdf.json      ->  {"note": "Q3 lead report", "meta": "Nov 2026"}
```

`note` becomes the row title, `meta` the grey subtitle.

## Building the cabinet from a script

Anything that writes a file here is instantly visible on the page — no publish
step, no manifest to regenerate. That is the whole point: the page reads the
folder.
