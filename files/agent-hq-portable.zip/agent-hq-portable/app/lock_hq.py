#!/usr/bin/env python3
"""
lock_html.py - password-lock a single-file HTML page.

Produces a self-contained "gate" page: the original HTML is encrypted with
AES-256-GCM (key = PBKDF2-HMAC-SHA256 of the password) and embedded as base64.
The browser decrypts it with WebCrypto only when the right password is typed.
No server, no backend, no host support needed -> works on GitHub Pages,
Cloudflare Pages, a USB stick, or file://.

Requires: python `cryptography` package (pip install cryptography)

Usage:
  python lock_html.py --in hosted/index.html --out hosted/index.locked.html --password 'secret'
  python lock_html.py --in hosted/index.html --out hosted/index.locked.html --password-file pw.txt

Verified end-to-end Sep 2026 (wrong password rejected, correct password
restored a 27KB page byte-exact, inline scripts executed after decrypt).
"""
import argparse
import base64
import os
import sys

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

ITERATIONS = 250_000

TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title>__TITLE__ - locked</title>
<style>
  :root{ --bg:#0b0d17; --pan:#141827; --line:#252b45; --txt:#e7e9f5; --dim:#8b93b5;
         --acc:#a78bfa; --warn:#f87171; }
  *{box-sizing:border-box}
  html,body{height:100%}
  body{margin:0;background:radial-gradient(1200px 700px at 50% -10%,#1b2140 0%,var(--bg) 60%);
       color:var(--txt);font:15px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
       display:flex;align-items:center;justify-content:center;padding:24px}
  .box{width:100%;max-width:380px;background:var(--pan);border:1px solid var(--line);border-radius:16px;
       padding:26px 22px 22px;box-shadow:0 24px 60px rgba(0,0,0,.55);text-align:center}
  .lock{font-size:40px;line-height:1;margin-bottom:6px}
  h1{margin:6px 0 2px;font-size:16px;letter-spacing:.16em;text-transform:uppercase}
  .sub{color:var(--dim);font-size:11.5px;letter-spacing:.08em;margin-bottom:20px}
  input{width:100%;padding:12px 13px;border-radius:10px;border:1px solid var(--line);
        background:#0e1120;color:var(--txt);font:inherit;outline:none}
  input:focus{border-color:var(--acc);box-shadow:0 0 0 3px rgba(167,139,250,.16)}
  button{width:100%;margin-top:11px;padding:12px;border:0;border-radius:10px;cursor:pointer;
         background:linear-gradient(180deg,var(--acc),#7c5cf5);color:#14102a;font:inherit;
         font-weight:700;letter-spacing:.06em}
  button:disabled{opacity:.55;cursor:progress}
  .err{color:var(--warn);font-size:12px;min-height:16px;margin-top:11px}
  .note{color:var(--dim);font-size:10.5px;margin-top:16px;letter-spacing:.04em}
</style>
</head>
<body>
  <div class="box">
    <div class="lock">&#128274;</div>
    <h1>__TITLE__</h1>
    <div class="sub">encrypted &middot; password required</div>
    <form id="f" autocomplete="off">
      <input id="pw" type="password" placeholder="password" autocomplete="current-password" autofocus />
      <button id="go" type="submit">UNLOCK</button>
    </form>
    <div class="err" id="err"></div>
    <div class="note">AES-256-GCM &middot; PBKDF2-SHA256 &middot; __ITER__ rounds</div>
  </div>
<script>
const ITER = __ITER__;
const SALT = "__SALT__";
const IV   = "__IV__";
const CT   = "__CT__";
const errEl = document.getElementById('err');
const goEl  = document.getElementById('go');
const pwEl  = document.getElementById('pw');

function fromB64(s) {
  const bin = atob(s.replace(/-/g, '+').replace(/_/g, '/'));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function decrypt(pw) {
  const enc = new TextEncoder();
  const base = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: fromB64(SALT), iterations: ITER, hash: 'SHA-256' },
    base, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(IV) }, key, fromB64(CT));
  return new TextDecoder().decode(pt);
}

// Hard-replace the gate with the decrypted page, rendered into a full-screen
// same-origin frame. document.write() must NOT be used here: several mobile
// browsers append the written markup instead of replacing the document (or
// block post-load document.write outright as an intervention), which leaves the
// lock panel painted over/next to the dashboard. Reported on a phone, Sep 2026.
function render(html) {
  try {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const pageTitle = (doc.querySelector('title') && doc.querySelector('title').textContent) || '__TITLE__';
    // Relative URLs (status.json, assets) must resolve against THIS page, not the
    // frame's own blob:/about:srcdoc URL.
    const baseTag = '<base href="' + location.href.replace(/&/g, '&amp;').replace(/"/g, '&quot;') + '">';
    const page = html.replace(/<head([^>]*)>/i, '<head$1>' + baseTag);

    document.title = pageTitle;
    document.head.innerHTML = '<title>' + pageTitle + '</title>';   // drop the gate's styles entirely
    document.documentElement.style.cssText = 'margin:0;padding:0;height:100%;background:#0b0d17';
    document.body.style.cssText = 'margin:0;padding:0;overflow:hidden;background:#0b0d17';
    document.body.innerHTML = '';                                    // drop the lock panel

    const frame = document.createElement('iframe');
    frame.setAttribute('title', pageTitle);
    frame.setAttribute('allow', 'clipboard-write');
    frame.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;background:#0b0d17';
    // keep external links (the Telegram switch deep-link) from navigating inside the frame
    frame.addEventListener('load', () => {
      try {
        frame.contentDocument.querySelectorAll('a[href]').forEach(a => {
          a.target = '_blank';
          a.rel = 'noopener';
        });
      } catch (x) {}
    });
    try {
      frame.src = URL.createObjectURL(new Blob([page], { type: 'text/html' }));
    } catch (x) {
      frame.srcdoc = page;                                           // fallback: no blob URL support
    }
    document.body.appendChild(frame);
  } catch (x) {
    document.open(); document.write(html); document.close();        // last resort
  }
}

// refresh within the same tab shouldn't re-prompt (cleared when the tab closes)
const cached = sessionStorage.getItem('__CACHEKEY__');
if (cached) {
  render(cached);
} else {
  document.getElementById('f').addEventListener('submit', async e => {
    e.preventDefault();
    errEl.textContent = '';
    goEl.disabled = true;
    goEl.textContent = 'DECRYPTING\u2026';
    try {
      const html = await decrypt(pwEl.value);
      try { sessionStorage.setItem('__CACHEKEY__', html); } catch (x) {}
      render(html);
    } catch (x) {
      errEl.textContent = (x && x.name === 'OperationError')
        ? 'Wrong password.'
        : 'Cannot decrypt here: ' + (x && x.message ? x.message : x);
      goEl.disabled = false;
      goEl.textContent = 'UNLOCK';
      pwEl.select();
    }
  });
}
</script>
</body>
</html>
"""


def lock(html_bytes: bytes, password: str, title: str, cache_key: str, iterations: int) -> str:
    salt = os.urandom(16)
    iv = os.urandom(12)
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
    key = kdf.derive(password.encode("utf-8"))
    ct = AESGCM(key).encrypt(iv, html_bytes, None)
    b64 = lambda b: base64.b64encode(b).decode("ascii")  # noqa: E731
    return (TEMPLATE
            .replace("__ITER__", str(iterations))
            .replace("__SALT__", b64(salt))
            .replace("__IV__", b64(iv))
            .replace("__CT__", b64(ct))
            .replace("__TITLE__", title)
            .replace("__CACHEKEY__", cache_key))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="src", required=True)
    ap.add_argument("--out", dest="dst", required=True)
    ap.add_argument("--password")
    ap.add_argument("--password-file")
    ap.add_argument("--title", default="AGENT HQ")
    ap.add_argument("--iterations", type=int, default=ITERATIONS)
    a = ap.parse_args()

    pw = a.password
    if not pw and a.password_file:
        with open(a.password_file, "r", encoding="utf-8") as f:
            pw = f.read().strip()
    if not pw:
        return print("error: pass --password or --password-file") or 2
    if len(pw) < 6:
        return print("error: password too short (min 6 chars)") or 2

    with open(a.src, "rb") as f:
        html = f.read()

    cache_key = "hq_unlocked_" + base64.b16encode(os.urandom(6)).decode("ascii").lower()
    out = lock(html, pw, a.title, cache_key, a.iterations)

    with open(a.dst, "w", encoding="utf-8") as f:
        f.write(out)

    print(f"locked: {a.src} ({len(html)} bytes) -> {a.dst} ({len(out)} bytes)")
    print(f"iterations: {a.iterations}  title: {a.title}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
