@echo off
rem Agent HQ launcher. Serves the office page on localhost only.
rem Usage:  start_hq.cmd            (page as-is)
rem         start_hq.cmd --locked   (serve the password-gated copy)
setlocal
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
"%PY%" switch_server.py %*
if errorlevel 1 pause
