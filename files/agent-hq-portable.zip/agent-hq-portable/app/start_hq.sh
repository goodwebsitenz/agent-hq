#!/usr/bin/env bash
# Agent HQ launcher. Serves the office page on localhost only.
# Usage:  ./start_hq.sh            (page as-is)
#         ./start_hq.sh --locked   (serve the password-gated copy)
cd "$(dirname "$0")" || exit 1
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
exec "$PY" switch_server.py "$@"
