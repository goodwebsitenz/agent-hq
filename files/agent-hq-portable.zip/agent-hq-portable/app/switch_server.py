#!/usr/bin/env python3
"""
Agent HQ — local control panel for a Hermes Agent install.

Serves the isometric office page and answers:

  GET  /                     the HQ page (index.html, or index.locked.html if present)
  GET  /api/status           live profile, every profile's seat, model and cron summary
  GET  /api/files            the file cabinet: everything in ./cabinet/
  GET  /cabinet/<name>       a cabinet file
  POST /api/switch           {"profile": "<id>"} -> make that profile live, restart the gateway
  GET  /switch?profile=<id>  same thing but returns a small HTML page (linkable from a phone)
  POST /api/agents           {"label","role","model","provider","dot","slot"} -> new profile

Run:   python switch_server.py [port] [--locked]
Env:   HERMES_HOME      where the Hermes root is (default: ~/.hermes)
       HQ_RESTART_CMD   command that restarts the gateway (default: "hermes gateway restart")
       HQ_PAGE          page to serve at / (default: index.html)
       HQ_BIND          bind address (default 127.0.0.1 — do not expose this)

Stdlib only. Binds to localhost: there is NO authentication on this server, so it
must never be reachable from the network. Access is gated by your chat channel.
"""
import json
import mimetypes
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

HERE = Path(__file__).resolve().parent
CABINET = HERE / "cabinet"
AGENTS_JSON = HERE / "agents.json"

COLOURS = ["#7c6cf0", "#12b6c9", "#e0a01c", "#3d84e8", "#37a86a", "#e8548f", "#f2742c"]
MAX_SLOTS = 7
KIND_BY_EXT = {
    ".png": "image", ".jpg": "image", ".jpeg": "image", ".gif": "image", ".webp": "image", ".svg": "image",
    ".mp4": "video", ".mov": "video", ".webm": "video", ".mkv": "video",
    ".mp3": "audio", ".wav": "audio", ".ogg": "audio", ".m4a": "audio", ".flac": "audio",
    ".srt": "subs", ".vtt": "subs",
    ".pdf": "doc", ".md": "doc", ".txt": "doc", ".docx": "doc", ".xlsx": "doc",
    ".csv": "doc", ".json": "doc", ".html": "doc",
}


# --------------------------------------------------------------------------- root
def find_root() -> Path:
    """The Hermes root: HERMES_HOME, else ~/.hermes, else ~/AppData/Local/hermes."""
    cands = []
    env = os.environ.get("HERMES_HOME")
    if env:
        cands.append(Path(env))
    cands.append(Path.home() / ".hermes")
    for c in cands:
        if (c / "config.yaml").exists() or (c / "profiles").is_dir():
            return c.resolve()
    return cands[0]


HERMES = find_root()
PROFILES_DIR = HERMES / "profiles"
ACTIVE_FILE = HERMES / "active_profile"


# --------------------------------------------------------------------- metadata
def read_meta() -> dict:
    try:
        d = json.loads(AGENTS_JSON.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    agents = d.get("agents") if isinstance(d, dict) else None
    return {"agents": agents if isinstance(agents, list) else []}


def write_meta(meta: dict):
    tmp = AGENTS_JSON.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(meta, indent=1), encoding="utf-8")
    tmp.replace(AGENTS_JSON)


def meta_by_id() -> dict:
    return {a.get("id"): a for a in read_meta()["agents"] if a.get("id")}


# ---------------------------------------------------------------------- profiles
def profile_ids() -> list:
    ids = ["default"]
    if PROFILES_DIR.is_dir():
        for p in sorted(PROFILES_DIR.iterdir()):
            if p.is_dir() and (p / "config.yaml").exists() and p.name != "default":
                ids.append(p.name)
    return ids


def profile_dir(pid: str) -> Path:
    return HERMES if pid == "default" else PROFILES_DIR / pid


def read_active() -> str:
    try:
        return (ACTIVE_FILE.read_text(encoding="utf-8").strip() or "default")
    except OSError:
        return "default"


def model_of(pid: str) -> dict:
    """Pull the model block out of a profile's config.yaml without needing PyYAML."""
    cfg = profile_dir(pid) / "config.yaml"
    out = {"model": "", "provider": ""}
    try:
        lines = cfg.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return out
    in_model = False
    for line in lines:
        if re.match(r"^model:\s*$", line):
            in_model = True
            continue
        if in_model:
            if line and not line.startswith((" ", "\t")):
                break
            m = re.match(r"^\s+default:\s*(\S+)", line)
            if m and not out["model"]:
                out["model"] = m.group(1).strip("'\"")
                continue
            m = re.match(r"^\s+model:\s*(\S+)", line)
            if m and not out["model"]:
                out["model"] = m.group(1).strip("'\"")
                continue
            m = re.match(r"^\s+provider:\s*(\S+)", line)
            if m and not out["provider"]:
                out["provider"] = m.group(1).strip("'\"")
    return out


def cron_summary(pid: str) -> str:
    """How many scheduled jobs this profile owns, and whether they are live."""
    paths = [profile_dir(pid) / "cron" / "jobs.json"]
    jobs = []
    for p in paths:
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        js = d.get("jobs") if isinstance(d, dict) else d
        if isinstance(js, list):
            jobs = js
            break
    if not jobs:
        return "none"
    live, paused, names = 0, 0, []
    for j in jobs:
        enabled = j.get("enabled")
        if enabled is None:
            enabled = not j.get("paused", False)
        if enabled:
            live += 1
        else:
            paused += 1
        if j.get("name"):
            names.append(str(j["name"]))
    bits = [f"{live} live" if live else "", f"{paused} paused" if paused else ""]
    head = f"{len(jobs)} job" + ("s" if len(jobs) != 1 else "") + " — " + ", ".join(b for b in bits if b)
    if names:
        head += ": " + ", ".join(names[:4]) + ("…" if len(names) > 4 else "")
    return head


def assign_slots(ids: list) -> dict:
    """default is always seat 0; everyone else keeps the seat they were created at."""
    meta = meta_by_id()
    used, slots = set(), {}
    if "default" in ids:
        slots["default"] = 0
        used.add(0)
    for pid in ids:
        if pid == "default":
            continue
        s = meta.get(pid, {}).get("slot")
        if isinstance(s, int) and 0 <= s < MAX_SLOTS and s not in used:
            slots[pid] = s
            used.add(s)
    nxt = 1
    for pid in ids:
        if pid in slots:
            continue
        while nxt in used and nxt < MAX_SLOTS:
            nxt += 1
        slots[pid] = nxt if nxt < MAX_SLOTS else MAX_SLOTS - 1
        used.add(slots[pid])
    return slots


def status_payload() -> dict:
    ids = profile_ids()
    slots = assign_slots(ids)
    meta = meta_by_id()
    active = read_active()
    profiles = []
    for pid in ids:
        m = meta.get(pid, {})
        mm = model_of(pid)
        model = m.get("model") or mm["model"] or "?"
        provider = m.get("provider") or mm["provider"] or "?"
        profiles.append({
            "id": pid,
            "label": m.get("label") or pid.replace("-", " ").title(),
            "role": m.get("role") or "Hermes agent",
            "dot": m.get("dot") or COLOURS[slots.get(pid, 0) % len(COLOURS)],
            "slot": slots.get(pid, 0),
            "model": model,
            "provider": provider,
            "proc": f"{model} · {provider}",
            "cron": cron_summary(pid),
            "auto": m.get("auto") or "—",
            "is_active": pid == active,
        })
    profiles.sort(key=lambda p: p["slot"])
    return {
        "ok": True,
        "active": active,
        "root": str(HERMES),
        "profiles": profiles,
        "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


# ------------------------------------------------------------------------ switch
def restart_cmd() -> list:
    env = os.environ.get("HQ_RESTART_CMD")
    if env:
        return shlex.split(env)
    exe = shutil.which("hermes") or shutil.which("hermes.cmd") or shutil.which("hermes.exe")
    if not exe:
        raise RuntimeError("cannot find the hermes CLI — set HQ_RESTART_CMD")
    return [exe, "gateway", "restart"]


def spawn_restart() -> None:
    cmd = restart_cmd()
    kwargs = {"cwd": str(HERE), "close_fds": True}
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000008 | 0x00000200  # DETACHED_PROCESS | NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(cmd, **kwargs)


def do_switch(pid: str):
    if pid not in profile_ids():
        return 400, {"ok": False, "error": f"unknown profile: {pid}"}
    prev = read_active()
    if pid == prev:
        return 200, {"ok": True, "already": True, "active": prev}
    try:
        ACTIVE_FILE.write_text(pid, encoding="utf-8")
    except OSError as e:
        return 500, {"ok": False, "error": f"cannot write active_profile: {e}"}
    try:
        spawn_restart()
    except Exception as e:
        try:
            ACTIVE_FILE.write_text(prev, encoding="utf-8")
        except OSError:
            pass
        return 500, {"ok": False, "error": f"restart failed, rolled back to {prev}: {e}"}
    return 200, {"ok": True, "switched": pid, "previous": prev}


# ----------------------------------------------------------------- create agent
def slugify(label: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", label.lower()).strip("-")
    return (s or "agent")[:32]


def set_model_in_config(cfg: Path, model: str, provider: str) -> list:
    """Rewrite only the top-level model block. Returns the notes for the caller."""
    try:
        lines = cfg.read_text(encoding="utf-8").splitlines(keepends=True)
    except OSError:
        return ["config.yaml unreadable — model left as inherited"]
    notes, in_model, touched = [], False, set()
    for i, line in enumerate(lines):
        if re.match(r"^model:\s*$", line):
            in_model = True
            continue
        if in_model:
            if line.strip() and not line.startswith((" ", "\t")):
                break
            if model and re.match(r"^\s+default:", line):
                lines[i] = re.sub(r"(^\s+default:\s*)\S+", lambda m: m.group(1) + model, line)
                touched.add("model")
            elif model and re.match(r"^\s+model:", line):
                lines[i] = re.sub(r"(^\s+model:\s*)\S+", lambda m: m.group(1) + model, line)
                touched.add("model")
            elif provider and re.match(r"^\s+provider:", line):
                lines[i] = re.sub(r"(^\s+provider:\s*)\S+", lambda m: m.group(1) + provider, line)
                touched.add("provider")
    if model and "model" not in touched:
        notes.append("model field not found — left as inherited")
    if provider and "provider" not in touched:
        notes.append("provider field not found — left as inherited")
    if touched:
        try:
            cfg.write_text("".join(lines), encoding="utf-8")
        except OSError as e:
            notes.append(f"could not write config.yaml: {e}")
    return notes


def do_create_agent(payload: dict):
    label = str(payload.get("label") or "").strip()
    if not label:
        return 400, {"ok": False, "error": "name required"}
    role = str(payload.get("role") or "").strip() or "Hermes agent"
    model = str(payload.get("model") or "").strip()
    provider = str(payload.get("provider") or "").strip()
    dot = str(payload.get("dot") or "").strip() or None
    want_slot = payload.get("slot")
    want_slot = want_slot if isinstance(want_slot, int) and 0 <= want_slot < MAX_SLOTS else None

    ids = profile_ids()
    if len(ids) >= MAX_SLOTS:
        return 409, {"ok": False, "error": f"all {MAX_SLOTS} seats are taken"}

    slug, n = slugify(label), 2
    while slug in ids or (PROFILES_DIR / slug).exists():
        slug = f"{slugify(label)}-{n}"
        n += 1

    dest = PROFILES_DIR / slug
    src = profile_dir("default")
    try:
        dest.mkdir(parents=True, exist_ok=False)
        shutil.copy2(src / "config.yaml", dest / "config.yaml")
        env_src = src / ".env"
        if env_src.exists():
            shutil.copy2(env_src, dest / ".env")
            try:
                os.chmod(dest / ".env", 0o600)
            except OSError:
                pass
    except Exception as e:
        return 500, {"ok": False, "error": f"could not create profile folder: {e}"}

    notes = set_model_in_config(dest / "config.yaml", model, provider)
    if provider:
        try:
            cfg_txt = (dest / "config.yaml").read_text(encoding="utf-8")
        except OSError:
            cfg_txt = ""
        if re.search(r"^\s+base_url:\s*\S", cfg_txt, re.M):
            notes.append("config.yaml still carries the default profile's base_url — "
                         "clear it if your new provider uses a different endpoint")

    meta = read_meta()
    slots_taken = {a.get("slot") for a in meta["agents"]}
    if want_slot is None or want_slot in slots_taken or want_slot == 0:
        free = [s for s in range(1, MAX_SLOTS) if s not in slots_taken]
        want_slot = free[0] if free else 1
    meta["agents"] = [a for a in meta["agents"] if a.get("id") != slug]
    meta["agents"].append({
        "id": slug, "label": label, "role": role, "slot": want_slot,
        "dot": dot or COLOURS[want_slot % len(COLOURS)],
        "model": model, "provider": provider,
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    })
    write_meta(meta)

    return 200, {
        "ok": True, "id": slug, "slot": want_slot,
        "path": str(dest), "notes": notes,
        "hint": f"start it with: hermes --profile {slug}",
    }


# ------------------------------------------------------------------------ files
def list_files() -> list:
    out = []
    if not CABINET.is_dir():
        return out
    for p in sorted(CABINET.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or p.name == "README.md":
            continue
        if p.suffix.lower() == ".json" and (p.with_suffix("")).exists():
            continue  # a sidecar note, not a file in its own right
        rel = p.relative_to(CABINET).as_posix()
        note, meta = "", ""
        side = p.with_suffix(p.suffix + ".json")
        if side.exists():
            try:
                d = json.loads(side.read_text(encoding="utf-8"))
                note = str(d.get("note") or "")
                meta = str(d.get("meta") or "")
            except Exception:
                pass
        st = p.stat()
        out.append({
            "name": note or p.name,
            "file": rel,
            "url": "/cabinet/" + rel,
            "kind": KIND_BY_EXT.get(p.suffix.lower(), "doc"),
            "size": st.st_size,
            "meta": meta or datetime.fromtimestamp(st.st_mtime).strftime("%d %b %Y"),
            "added": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(timespec="seconds"),
            "note": note if note else "",
        })
    out.sort(key=lambda f: f["added"], reverse=True)
    return out


# ----------------------------------------------------------------------- server
class Handler(BaseHTTPRequestHandler):
    server_version = "AgentHQ/1.0"

    def log_message(self, fmt, *args):
        try:
            with open(HERE / "server.log", "a", encoding="utf-8") as f:
                f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), fmt % args))
        except OSError:
            pass

    # -- helpers
    def _send(self, code: int, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _file(self, path: Path, ctype=None):
        try:
            data = path.read_bytes()
        except OSError:
            self._send(404, {"ok": False, "error": "not found"})
            return
        self._send(200, data, ctype or mimetypes.guess_type(path.name)[0] or "application/octet-stream")

    def _page(self) -> Path:
        want = os.environ.get("HQ_PAGE") or ("index.locked.html" if LOCKED_ONLY else "index.html")
        p = HERE / want
        if not p.exists():
            p = HERE / "index.html"
        if not p.exists():
            p = HERE / "index.locked.html"
        return p

    # -- GET
    def do_GET(self):
        u = urlparse(self.path)
        path, q = unquote(u.path), parse_qs(u.query)

        if path in ("/", "/index.html"):
            p = self._page()
            if not p.exists():
                self._send(500, {"ok": False, "error": "no page in this folder"})
            else:
                self._file(p, "text/html; charset=utf-8")
            return
        if path == "/api/status":
            self._send(200, status_payload())
            return
        if path == "/api/files":
            self._send(200, {"ok": True, "files": list_files()})
            return
        if path.startswith("/cabinet/"):
            target = (CABINET / path[len("/cabinet/"):]).resolve()
            try:
                target.relative_to(CABINET.resolve())
            except ValueError:
                self._send(403, {"ok": False, "error": "outside the cabinet"})
                return
            self._file(target)
            return
        if path == "/switch":
            pid = (q.get("profile") or [""])[0]
            code, payload = do_switch(pid)
            if payload.get("already"):
                msg = f"{pid.upper()} is already live — nothing to restart."
            elif payload.get("switched"):
                msg = f"Switching to {pid.upper()}… the gateway is rebooting."
            else:
                msg = f"Switch failed: {payload.get('error', 'unknown error')}"
            html = (
                "<!doctype html><html><head><meta charset='utf-8'>"
                "<meta http-equiv='refresh' content='5;url=/'>"
                "<title>Agent HQ</title></head>"
                "<body style='font-family:system-ui;background:#eef2f6;color:#1e2a35;"
                "display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
                f"<div style='text-align:center'><h2>{msg}</h2>"
                "<p>Back to the office in a moment…</p></div></body></html>"
            ).encode("utf-8")
            self._send(code, html, "text/html; charset=utf-8")
            return
        self._send(404, {"ok": False, "error": "not found"})

    # -- POST
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(payload, dict):
                raise ValueError
        except Exception:
            self._send(400, {"ok": False, "error": "bad request body"})
            return

        if path == "/api/switch":
            code, resp = do_switch(str(payload.get("profile") or ""))
            self._send(code, resp)
            return
        if path == "/api/agents":
            code, resp = do_create_agent(payload)
            self._send(code, resp)
            return
        self._send(404, {"ok": False, "error": "not found"})


LOCKED_ONLY = False


def main(argv=None) -> int:
    global LOCKED_ONLY
    argv = list(sys.argv[1:] if argv is None else argv)
    port = 8899
    for a in argv:
        if a == "--locked":
            LOCKED_ONLY = True
        elif a.isdigit():
            port = int(a)
    bind = os.environ.get("HQ_BIND", "127.0.0.1")
    CABINET.mkdir(parents=True, exist_ok=True)
    srv = ThreadingHTTPServer((bind, port), Handler)
    print(f"Agent HQ  http://{bind}:{port}")
    print(f"hermes root: {HERMES}")
    print(f"profiles:   {', '.join(profile_ids())}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
